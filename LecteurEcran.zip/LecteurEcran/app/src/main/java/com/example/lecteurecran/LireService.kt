package com.example.lecteurecran

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import java.util.Locale
import kotlin.math.abs

/** Une zone de texte détectée à l'écran. */
data class Zone(val rect: Rect, val text: String)

class LireService : AccessibilityService(), TextToSpeech.OnInitListener {

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var utteranceCounter = 0
    private var currentUtterance: String? = null

    private var bubble: BubbleView? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var overlay: ZonesView? = null
    private var active = false

    // ---------- Cycle de vie ----------

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        tts = TextToSpeech(this, this)
        addBubble()
    }

    override fun onInit(status: Int) {
        val engine = tts ?: return
        if (status == TextToSpeech.SUCCESS) {
            val result = engine.setLanguage(Locale.getDefault())
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA &&
                result != TextToSpeech.LANG_NOT_SUPPORTED
            engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) = finished(utteranceId)
                override fun onStop(utteranceId: String?, interrupted: Boolean) = finished(utteranceId)

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) = finished(utteranceId)
            })
        }
    }

    private fun finished(id: String?) {
        handler.post {
            if (id != null && id == currentUtterance) {
                currentUtterance = null
                overlay?.speaking = null
            }
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {
        tts?.stop()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // Les positions des zones ne sont plus valables après une rotation.
        if (active) deactivate()
    }

    override fun onDestroy() {
        removeOverlay()
        removeBubble()
        tts?.stop()
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }

    // ---------- Bulle flottante ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun addBubble() {
        val view = BubbleView(this).also { it.active = active }
        val params = bubbleParams ?: WindowManager.LayoutParams(
            dp(56),
            dp(56),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8)
            y = dp(200)
        }
        bubbleParams = params

        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false

        view.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = e.rawX
                    touchY = e.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - touchX
                    val dy = e.rawY - touchY
                    if (!moved && (abs(dx) > slop || abs(dy) > slop)) moved = true
                    if (moved) {
                        params.x = startX + dx.toInt()
                        params.y = startY + dy.toInt()
                        try {
                            wm.updateViewLayout(view, params)
                        } catch (_: IllegalArgumentException) {
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) handler.post { toggle() }
                    true
                }
                else -> false
            }
        }

        wm.addView(view, params)
        bubble = view
    }

    private fun removeBubble() {
        bubble?.let {
            try {
                wm.removeView(it)
            } catch (_: IllegalArgumentException) {
            }
        }
        bubble = null
    }

    // ---------- Activation / désactivation ----------

    private fun toggle() {
        if (active) deactivate() else activate()
    }

    private fun activate() {
        val root = rootInActiveWindow
        if (root == null) {
            toast("Impossible de lire l'écran pour le moment")
            return
        }
        val zones = mutableListOf<Zone>()
        collect(root, zones)
        if (zones.isEmpty()) {
            toast("Aucun texte détecté sur cet écran")
            return
        }

        val view = ZonesView(this, zones) { zone -> speak(zone) }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(view, lp)
        overlay = view
        active = true

        // Remet la bulle au-dessus de la couche de surbrillance.
        removeBubble()
        addBubble()
    }

    private fun deactivate() {
        tts?.stop()
        currentUtterance = null
        removeOverlay()
        active = false
        bubble?.active = false
    }

    private fun removeOverlay() {
        overlay?.let {
            try {
                wm.removeView(it)
            } catch (_: IllegalArgumentException) {
            }
        }
        overlay = null
    }

    // ---------- Lecture ----------

    private fun collect(node: AccessibilityNodeInfo?, out: MutableList<Zone>) {
        if (node == null || !node.isVisibleToUser) return
        val text = (node.text ?: node.contentDescription)?.toString()?.trim()
        if (!text.isNullOrEmpty()) {
            val r = Rect()
            node.getBoundsInScreen(r)
            if (r.width() > 0 && r.height() > 0) out.add(Zone(r, text))
        }
        for (i in 0 until node.childCount) collect(node.getChild(i), out)
    }

    private fun speak(zone: Zone) {
        val engine = tts
        if (engine == null || !ttsReady) {
            toast("La synthèse vocale n'est pas disponible")
            return
        }
        val view = overlay ?: return
        if (view.speaking === zone) {
            // Second appui sur la zone en cours de lecture : on arrête.
            engine.stop()
            currentUtterance = null
            view.speaking = null
            return
        }
        val id = "z${++utteranceCounter}"
        currentUtterance = id
        view.speaking = zone
        engine.speak(zone.text, TextToSpeech.QUEUE_FLUSH, null, id)
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}

/** Bulle ronde affichée au-dessus des autres applications. */
class BubbleView(context: Context) : View(context) {

    var active = false
        set(value) {
            field = value
            invalidate()
        }

    private val circle = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glyph = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        color = Color.WHITE
    }

    override fun onDraw(canvas: Canvas) {
        circle.color = if (active) Color.parseColor("#2E7D32") else Color.parseColor("#1565C0")
        val cx = width / 2f
        val cy = height / 2f
        canvas.drawCircle(cx, cy, width / 2f - 2f, circle)
        glyph.textSize = height * 0.5f
        val offset = (glyph.descent() + glyph.ascent()) / 2f
        canvas.drawText(if (active) "✕" else "🔊", cx, cy - offset, glyph)
    }
}

/** Couche plein écran qui surligne les zones de texte et réagit aux appuis. */
class ZonesView(
    context: Context,
    private val zones: List<Zone>,
    private val onZoneTap: (Zone) -> Unit
) : View(context) {

    var speaking: Zone? = null
        set(value) {
            field = value
            invalidate()
        }

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(0x44000000)
        val loc = IntArray(2)
        getLocationOnScreen(loc)
        for (z in zones) {
            val r = RectF(z.rect)
            r.offset(-loc[0].toFloat(), -loc[1].toFloat())
            val isSpeaking = z === speaking
            fill.color = if (isSpeaking) 0x884CAF50.toInt() else 0x66FFEB3B
            stroke.color = if (isSpeaking) 0xFF2E7D32.toInt() else 0xFFFF9800.toInt()
            canvas.drawRect(r, fill)
            canvas.drawRect(r, stroke)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_UP) {
            val x = e.rawX.toInt()
            val y = e.rawY.toInt()
            // Si plusieurs zones se chevauchent, on prend la plus petite (la plus précise).
            zones.filter { it.rect.contains(x, y) }
                .minByOrNull { it.rect.width().toLong() * it.rect.height() }
                ?.let(onZoneTap)
        }
        return true
    }
}
