package com.example.lecteurecran

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (24 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        val title = TextView(this).apply {
            text = "Lecteur d'écran"
            textSize = 24f
        }
        val help = TextView(this).apply {
            textSize = 16f
            setPadding(0, pad / 2, 0, pad)
            text = "1. Appuyez sur le bouton ci-dessous.\n" +
                "2. Ouvrez « Lecteur d'écran » dans la liste (parfois sous « Applications installées »).\n" +
                "3. Activez le service.\n\n" +
                "Une bulle apparaît alors sur l'écran : glissez-la où vous voulez. " +
                "Touchez-la pour surligner les zones de texte, touchez une zone pour l'entendre, " +
                "retouchez la bulle pour quitter ce mode.\n\n" +
                "Pour retirer la bulle, désactivez le service dans les mêmes réglages."
        }
        val button = Button(this).apply {
            text = "Ouvrir les réglages d'accessibilité"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        layout.addView(title)
        layout.addView(help)
        layout.addView(button)
        setContentView(layout)
    }
}
