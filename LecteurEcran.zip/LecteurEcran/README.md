# Lecteur d'écran (bulle flottante)

Petite appli Android : une bulle déplaçable flotte au-dessus des autres applications.
Touchez-la pour surligner les zones de texte de l'écran, touchez une zone pour l'entendre,
retouchez la bulle pour désactiver.

## Compiler l'APK

1. Installer Android Studio, puis `File > Open` et choisir ce dossier.
2. Laisser Gradle se synchroniser (il télécharge tout seul ce qu'il faut).
3. `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
4. L'APK est dans `app/build/outputs/apk/debug/app-debug.apk`.

## Installer et activer

1. Copier l'APK sur le téléphone et l'installer (autoriser les sources inconnues si demandé).
2. Ouvrir l'appli, appuyer sur « Ouvrir les réglages d'accessibilité », activer « Lecteur d'écran ».
3. Sur Android 13+ : si l'option est grisée, `Infos de l'appli > ⋮ > Autoriser les réglages restreints`.

## Remarques

- L'appli lit uniquement les textes exposés par les applications (pas le texte dans une image).
- La voix utilisée est celle de la synthèse vocale du téléphone (Réglages > Synthèse vocale).
